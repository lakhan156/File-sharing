document.getElementById('uploadForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData();
    const fileInput = document.getElementById('file');
    formData.append('file', fileInput.files[0]);

    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();
        
        if (data.file) {
            const resultDiv = document.getElementById('result');
            resultDiv.style.display = 'block';
            resultDiv.innerHTML = `
                <h3>File Uploaded Successfully!</h3>
                <p>Share Link: <a href="${data.file.shareLink}" target="_blank">${data.file.shareLink}</a></p>
                <div class="qr-code">
                    <img src="${data.file.qrCode}" alt="QR Code">
                </div>
            `;
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while uploading the file');
    }
});