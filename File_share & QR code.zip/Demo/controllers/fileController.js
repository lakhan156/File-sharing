const File = require('../models/File');
const QRCode = require('qrcode');
const path = require('path');

exports.getHome = (req, res) => {
    res.render('index');
};

exports.uploadFile = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        // Get local IP address
        const os = require('os');
        const networkInterfaces = os.networkInterfaces();
        let localIP = '';
        
        // Find the local IP address
        Object.keys(networkInterfaces).forEach((interfaceName) => {
            networkInterfaces[interfaceName].forEach((interface) => {
                if (interface.family === 'IPv4' && !interface.internal) {
                    localIP = interface.address;
                }
            });
        });

        const file = new File({
            filename: req.file.filename,
            originalName: req.file.originalname,
            path: req.file.path,
            size: req.file.size,
            shareLink: `http://${localIP}:${process.env.PORT}/share/${req.file.filename}`,
            expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
        });

        // Generate QR Code
        const qrCode = await QRCode.toDataURL(file.shareLink);
        file.qrCode = qrCode;

        await file.save();
        res.json({ file });
    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({ error: 'Server error' });
    }
};
exports.getSharedFile = async (req, res) => {
    try {
        const file = await File.findOne({ filename: req.params.id });
        if (!file) {
            return res.status(404).render('error', { message: 'File not found' });
        }
        res.render('shared', { file });
    } catch (error) {
        res.status(500).render('error', { message: 'Server error' });
    }
};

exports.downloadFile = async (req, res) => {
    try {
        const file = await File.findOne({ filename: req.params.id });
        if (!file) {
            return res.status(404).json({ error: 'File not found' });
        }

        file.downloadCount++;
        await file.save();

        res.download(file.path, file.originalName);
    } catch (error) {
        res.status(500).json({ error: 'Server error' });
    }
};