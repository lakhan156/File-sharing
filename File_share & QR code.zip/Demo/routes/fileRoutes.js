const express = require('express');
const router = express.Router();
const fileController = require('../controllers/fileController');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    }
});

const upload = multer({ storage });

router.get('/', fileController.getHome);
router.post('/upload', upload.single('file'), fileController.uploadFile);
router.get('/share/:id', fileController.getSharedFile);
router.get('/download/:id', fileController.downloadFile);

module.exports = router;